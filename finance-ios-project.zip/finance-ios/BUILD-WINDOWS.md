# Finance App — Build the iOS app from Windows (no Mac needed)

Apple requires macOS + Xcode to compile iOS apps, so on Windows we borrow a
Mac in the cloud (GitHub Actions — free tier is plenty for this). You do all
your editing on Windows; the cloud does the compiling.

## What you need

- **Windows 10/11** with [Node.js 20 LTS](https://nodejs.org) and [Git](https://git-scm.com) installed
- A **GitHub account** (free)
- Your **iPhone** + a free **Apple ID** (for installing the app)
- Apple Developer membership ($99/yr) — **only** if you later want the App Store.
  Sideloading below needs no paid account.

## 1. Get the project on Windows

Unzip `finance-ios-project.zip`, open a terminal in the folder:

```
npm install
npx cap sync ios
```

`npx cap sync` works fine on Windows — it just copies your web files into the
iOS project. Whenever you edit anything in `www/` (the app itself), run it again.

## 2. Push to GitHub

```
git init
git add .
git commit -m "Finance iOS app"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/finance-ios.git
git push -u origin main
```

(Create the empty repo `finance-ios` on github.com first. Private is fine.)

The project ships a `.gitignore`, so `git add .` automatically skips
`node_modules/`, `ios/App/Pods/`, and the Capacitor-generated
`ios/App/App/public/` — about 135 files / 5 MB should be staged, not thousands.
Those folders are restored by `npm ci`, `pod install`, and `npx cap sync ios`,
which the Actions workflow runs for you.

**Dark mode:** Settings → Appearance (System / Light / Dark) or the 🌙 / ☀️
button in the app header. No build change needed — it's part of `www/`.

## 3. Build in the cloud

1. On github.com, open your repo → **Actions** tab.
2. Click **"iOS build (no Mac needed)"** → **Run workflow** → **Run workflow**.
3. Wait ~10–15 minutes. When it finishes, download the **`Finance-unsigned-ipa`**
   artifact and unzip it — you now have `Finance-unsigned.ipa` on Windows.

The IPA is **unsigned**, which is fine for sideloading (next step). GitHub's
free plan includes enough macOS minutes for occasional builds.

## 4. Install on your iPhone from Windows

**Option A — Sideloadly (easiest):**
1. Install [Sideloadly](https://sideloadly.io) on Windows and iTunes (for drivers).
2. Connect your iPhone via USB, open Sideloadly, drag in `Finance-unsigned.ipa`.
3. Enter your Apple ID → Start. (Free Apple IDs: apps must be re-installed every 7 days.)
4. On the iPhone: Settings → General → VPN & Device Management → trust your Apple ID.

**Option B — AltStore:** install AltStore on Windows/iPhone per
[altstore.io](https://altstore.io), then sideload the IPA through it.

Your finance data lives in the app's on-device storage — reinstalling later
keeps it only if you restore from a backup (see iCloud backup below).

## 5. iCloud backup (backup to your Apple account)

The app has a built-in **iCloud backup** in Settings (visible only in the
native app, not the web version):

- **Back up to iCloud now** — writes `finance-backup-<date>.json` into the
  app's Documents folder. With iCloud Drive enabled, iOS syncs it to your
  Apple account automatically. No extra sign-in needed.
- **Restore from iCloud** — restores the latest backup (with confirmation).
- **Auto-back up after each change** — same idea as the Google Drive toggle.

Find your backup files in the iPhone **Files** app → iCloud Drive (or
On My iPhone → Finance).

**Privacy note:** unlike the Google Drive backup, the iCloud file is *not*
passphrase-encrypted — it's protected by your iPhone's encryption and your
Apple account security. The app warns about this in Settings.

**One-time Apple setup (for the signed/App Store build):** the project
already ships an iCloud entitlement (`ios/App/App/App.entitlements`,
container `iCloud.com.manan.finance`, wired into the Xcode project). When you
move to a signed build, enable the **iCloud → iCloud Documents** capability
for the App ID at developer.apple.com (or let Xcode add it), using the same
bundle ID `com.manan.finance`. Unsigned sideloaded builds back up locally to
the app's Documents folder either way.

> **Heads-up for the free sideloading path:** Sideloadly can only apply custom
> app entitlements (like the iCloud one above) with a paid Apple Developer
> account, so on a free-Apple-ID install the iCloud entitlement is stripped.
> The app runs fine and the backup buttons still work — files just stay in
> the app's local Documents folder (Files → On My iPhone → Finance) instead
> of syncing to iCloud Drive. True iCloud sync needs the signed build
> (Section 6).

## 6. Going to the App Store later (still from Windows)

Use [Codemagic](https://codemagic.com) — it builds *and signs* from your
GitHub repo in the cloud:

1. Sign up, connect the `finance-ios` repo.
2. Add your Apple Developer **API key** (App Store Connect → Users and Access → Integrations).
3. Codemagic detects the Capacitor iOS project; enable iOS code signing and
   "Distribute to App Store Connect".
4. It uploads the build — you finish the listing in App Store Connect on the web.

In your App Store privacy answers, disclose: finance data stays on-device;
optional iCloud backup syncs an unencrypted JSON file to the user's own
iCloud Drive; optional Google Drive backup uploads an encrypted file to the
user's own Drive.

## Troubleshooting

| Problem | Fix |
|---|---|
| Workflow fails at `npm ci` | Make sure `package-lock.json` was committed |
| `pod install` fails | Re-run the workflow — transient CocoaPods CDN hiccups happen |
| IPA won't install | Use Sideloadly with a valid Apple ID; trust the developer certificate in iPhone Settings |
| App installs but iCloud card missing | The card only appears in the native app, not the web preview |
| No backups in Files app | Do one manual "Back up to iCloud now" first; check iCloud Drive is enabled in iPhone Settings → your name → iCloud |

## Iterating

1. Edit the app in `www/` on Windows.
2. `npx cap sync ios`
3. Commit + push → re-run the Actions workflow → install the fresh IPA.
