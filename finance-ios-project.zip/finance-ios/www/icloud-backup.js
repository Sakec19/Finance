/* iCloud backup for the native iOS wrapper (Capacitor).
 *
 * What it does: writes a plain-JSON backup of the whole app state into the
 * app's Documents/FinanceAppBackups/ folder using the Capacitor Filesystem
 * plugin. When the iCloud Documents capability is enabled for the app in
 * Xcode (see BUILD-WINDOWS.md / BUILD-IOS.md), iOS syncs everything under
 * Documents to the user's iCloud Drive automatically — that's the "backup
 * to your Apple account".
 *
 * Privacy note (shown in Settings): unlike the Google Drive backup, this
 * file is NOT passphrase-encrypted. It is protected by the device's data
 * protection + the user's Apple account / iCloud security instead.
 *
 * This file is a no-op on the web/PWA build — the Settings card stays
 * hidden unless we detect the native Capacitor platform.
 */
(function () {
  'use strict';

  var BACKUP_DIR = 'FinanceAppBackups';

  function cap() { return window.Capacitor || null; }
  function fs() {
    var c = cap();
    return (c && c.Plugins && c.Plugins.Filesystem) ? c.Plugins.Filesystem : null;
  }

  function isNative() {
    var c = cap();
    try {
      return !!(c && c.isNativePlatform && c.isNativePlatform() && fs());
    } catch (e) { return false; }
  }

  function $(id) { return document.getElementById(id); }

  function stamp(d) {
    function p(n) { return (n < 10 ? '0' : '') + n; }
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) +
      '-' + p(d.getHours()) + p(d.getMinutes());
  }

  function fileName() {
    return 'finance-backup-' + stamp(new Date()) + '.json';
  }

  function status(msg) {
    var el = $('icloudStatus');
    if (el) el.textContent = msg || '';
  }

  function settings() {
    return (window.state && window.state.settings) ? window.state.settings : {};
  }

  async function listBackups() {
    var F = fs();
    try {
      var res = await F.readdir({ path: BACKUP_DIR, directory: 'DOCUMENTS' });
      var files = (res.files || [])
        .map(function (f) { return typeof f === 'string' ? f : f.name; })
        .filter(function (n) { return /\.json$/i.test(n); })
        .sort();
      return files;
    } catch (e) {
      return []; // folder doesn't exist yet
    }
  }

  async function backupNow(opts) {
    opts = opts || {};
    var F = fs();
    if (!F) { if (!opts.silent) toast('iCloud backup needs the native app.'); return false; }
    if (!window.state) { if (!opts.silent) toast('Nothing to back up yet.'); return false; }
    try {
      var name = fileName();
      await F.writeFile({
        path: BACKUP_DIR + '/' + name,
        data: JSON.stringify(window.state, null, 2),
        directory: 'DOCUMENTS',
        recursive: true
      });
      var s = settings();
      s.icloudLastBackupAt = new Date().toISOString();
      if (typeof persist === 'function') persist(window.state);
      renderStatus();
      if (!opts.silent) toast('Backed up to iCloud Drive (' + name + ').');
      return true;
    } catch (e) {
      if (!opts.silent) toast('iCloud backup failed: ' + (e && e.message ? e.message : 'Unknown error'));
      return false;
    }
  }

  async function restoreNow() {
    var F = fs();
    if (!F) { toast('iCloud restore needs the native app.'); return; }
    try {
      var files = await listBackups();
      if (!files.length) { toast('No iCloud backups found yet.'); return; }
      var name = files[files.length - 1]; // latest by timestamped name
      if (!confirm('Replace everything on this device with the iCloud backup "' + name + '"? This cannot be undone.')) return;
      var res = await F.readFile({ path: BACKUP_DIR + '/' + name, directory: 'DOCUMENTS' });
      var text = typeof res.data === 'string' ? res.data : '';
      var obj = JSON.parse(text);
      var err = validateBackup(obj);
      if (err) { toast(err); return; }
      window.state = normalizeState(obj);
      if (typeof ui !== 'undefined') ui.openGoal = null;
      saveAndRender('Restored from iCloud backup.', { skipAutoBackup: true });
      renderStatus();
    } catch (e) {
      toast('Restore failed: ' + (e && e.message ? e.message : 'Unknown error'));
    }
  }

  function renderStatus() {
    var s = settings();
    var el = $('icloudAutoBackup');
    if (el) el.checked = !!s.icloudAutoBackup;
    if (s.icloudLastBackupAt) {
      var d = new Date(s.icloudLastBackupAt);
      status('Last iCloud backup: ' + d.toLocaleString() + '. Files sync to your iCloud Drive when iCloud Drive is on.');
    } else {
      status('No iCloud backup yet. Files sync to your iCloud Drive when iCloud Drive is on.');
    }
  }

  function wireAutoBackup() {
    // Mirror the Drive auto-backup: after every successful save, quietly
    // write a fresh iCloud backup when the toggle is on.
    if (typeof window.saveAndRender !== 'function') return;
    if (window.saveAndRender.__icloudWrapped) return;
    var orig = window.saveAndRender;
    var wrapped = function (msg, opts) {
      var r = orig.call(this, msg, opts);
      try {
        var s = settings();
        if (s.icloudAutoBackup && !(opts && opts.skipAutoBackup)) {
          backupNow({ silent: true }).catch(function () {});
        }
      } catch (e) {}
      return r;
    };
    wrapped.__icloudWrapped = true;
    window.saveAndRender = wrapped;
  }

  function ensureSettingsKeys() {
    // blankState() in app.js doesn't know about these keys; make sure they
    // exist with safe defaults on the live state object.
    var s = settings();
    if (typeof s.icloudAutoBackup === 'undefined') s.icloudAutoBackup = false;
    if (typeof s.icloudLastBackupAt === 'undefined') s.icloudLastBackupAt = '';
  }

  function init() {
    if (!isNative()) return; // web/PWA: leave the card hidden
    ensureSettingsKeys();
    var card = $('icloudCard');
    if (card) card.hidden = false;
    var b1 = $('btnIcloudBackup');
    var b2 = $('btnIcloudRestore');
    var t = $('icloudAutoBackup');
    if (b1) b1.addEventListener('click', function () { backupNow({}); });
    if (b2) b2.addEventListener('click', restoreNow);
    if (t) t.addEventListener('change', function () {
      settings().icloudAutoBackup = !!t.checked;
      if (typeof persist === 'function') persist(window.state);
      renderStatus();
      toast(t.checked ? 'iCloud auto-backup on.' : 'iCloud auto-backup off.');
    });
    wireAutoBackup();
    renderStatus();
  }

  window.iCloudBackup = {
    isAvailable: isNative,
    backupNow: backupNow,
    restoreNow: restoreNow,
    listBackups: listBackups
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
