# Finance — iOS App

Local-first personal finance tracker, wrapped as a native iOS app with **Capacitor 6**.

- **App name:** Finance
- **Bundle ID:** `com.manan.finance`
- **Web app:** `www/` — all data stays on-device in localStorage (`finance-app-v1`); works offline
- **Dark mode:** Settings → Appearance → **System / Light / Dark**, plus the 🌙 / ☀️ toggle in the header. System follows the device setting live; a manual choice is saved on-device only.

## Build

- **From Windows (no Mac):** see [BUILD-WINDOWS.md](BUILD-WINDOWS.md) — push to GitHub, run the **iOS build (no Mac needed)** Actions workflow, download `Finance-unsigned.ipa`, sideload with Sideloadly.
- **From a Mac:** see [BUILD-IOS.md](BUILD-IOS.md).

## Develop

```bash
npm ci
# edit the app in www/
npx cap sync ios   # copies www/ into the iOS project
```

Run the web tests:

```bash
node www/test-pwa.js
```

## Notes

- `node_modules/`, `ios/App/Pods/`, and the Capacitor-generated `ios/App/App/public/` are git-ignored — they are restored by `npm ci`, `pod install`, and `npx cap sync ios` (the GitHub Actions workflow does all three).
- **iCloud backup:** Settings card (native only) writes JSON backups to the app's Documents folder via an iCloud Documents entitlement (`iCloud.com.manan.finance`). Sideloading with a free Apple ID strips that entitlement, so backups stay local — see BUILD-WINDOWS.md.
- No financial data is sent to any cloud or external service by default.
