# Finance App — iOS Build Guide (Capacitor)

> **On Windows?** You don't need a Mac at all — see **BUILD-WINDOWS.md** for
> the cloud-build path (GitHub Actions + sideload with Sideloadly). The guide
> below is for building locally on a Mac with Xcode.

Your PWA has been wrapped as a native iOS app using **Capacitor 6**.
The project lives in this folder. You need a **Mac with Xcode** for the final build.

## What's in here

- `www/` — your web app (copied from `finance-app-pwa.zip`), with one small patch:
  the service-worker registration is skipped when running inside Capacitor
  (the app shell is already local on-device, and service workers don't apply
  on the `capacitor://` scheme).
- `ios/` — the native Xcode project (`ios/App/App.xcworkspace`).
  Open the **.xcworkspace**, not the .xcodeproj.
- `capacitor.config.json` — app ID `com.manan.finance`, app name `Finance`,
  web dir `www`.

## 1. Open on your Mac

1. Copy this whole `finance-ios` folder to your Mac (AirDrop, USB, or zip).
2. Install Node 20+ and CocoaPods:
   ```
   brew install node cocoapods
   ```
3. In the folder:
   ```
   npm install
   npx cap sync ios
   pod install --project-directory=ios/App   # only if CocoaPods warns
   ```
4. Open `ios/App/App.xcworkspace` in Xcode.

## 2. Set your identity & icons

1. In Xcode, select the **App** target → **Signing & Capabilities**:
   - Set **Team** to your Apple Developer team.
   - The Bundle Identifier is `com.manan.finance` (change it if you prefer).
2. **App icon:** in `ios/App/App/Assets.xcassets`, replace `AppIcon` with your
   icon. Your PWA's `www/icons/icon-512.png` (512×512) works as the source —
   drag it into an icon generator or Xcode's asset catalog.
3. **Display name:** already "Finance". Change under target → General if wanted.
4. **Splash screen:** Capacitor shows a launch storyboard; your PWA's
   `background_color #FAF7F1` is set as the webview background to avoid a flash.

## 3. Run on a device / simulator

- Simulator: pick an iPhone in the Xcode toolbar → **Run** (⌘R).
- Real iPhone: connect it, select it as the run destination, Run.
  First launch asks nothing — all finance data stays in the app's local
  WebKit storage on-device.

## 4. TestFlight / App Store

1. You need an **Apple Developer Program** membership ($99/yr).
2. In Xcode: **Product → Archive**, then **Distribute App** → App Store Connect.
3. In App Store Connect, create the app record (name "Finance", bundle
   `com.manan.finance`), fill in privacy details:
   - Data stays on-device; optional Google Drive backup uploads one encrypted
     file to the *user's own* Drive (disclose this in the privacy nutrition label).
4. Submit for review. Finance/personal-data apps sometimes get asked about
   data handling — point reviewers to the on-device privacy note in the README.

## Known limitations in the native wrapper

- **iCloud backup (new):** Settings now has an "iCloud backup (Apple)" card,
  visible only in the native app. It writes `finance-backup-<date>.json`
  into the app's Documents folder via the Capacitor Filesystem plugin, with
  optional auto-backup after each change. The Xcode project already includes
  the iCloud Documents entitlement (`ios/App/App/App.entitlements`, container
  `iCloud.com.manan.finance`), so on a *signed* build iOS syncs those files
  to the user's iCloud Drive automatically. In Xcode, confirm the **iCloud**
  capability is enabled for the App ID (Signing & Capabilities). Unlike the
  Google Drive backup, the iCloud file is **not** passphrase-encrypted — it
  relies on device encryption + the Apple account, and the Settings UI says so.
  Backups are also visible in the iPhone Files app (file sharing is enabled).

- **Google Drive cloud backup** (`Settings → Cloud backup`) uses Google
  Sign-In for Web (`accounts.google.com/gsi`). Inside the native app it opens
  in the system browser. It works, but the redirect back to the app needs
  testing on-device — if sign-in doesn't return cleanly, use the JSON
  **Backup & restore** (Settings) instead, which is fully offline.
- **Notifications:** the PWA's reminder banner works (it runs on app open).
  True push/local notifications would need the `@capacitor/local-notifications`
  plugin — not wired up in this v1 wrapper.
- **Service worker:** intentionally disabled in the wrapper; offline works
  because all assets ship inside the app bundle.

## Iterating

1. Edit files in `www/` (it's your app — `index.html`, `app.js`, `styles.css`).
2. Run `npx cap sync ios` to copy into the native project.
3. Re-run from Xcode. No need to re-add the platform.

## Useful commands

| Command | What it does |
|---|---|
| `npm run sync` | `npx cap sync ios` — copy www → native |
| `npx cap open ios` | Open the Xcode workspace |
| `npx cap doctor` | Diagnose Capacitor setup |

---
Generated from `finance-app-pwa.zip` (PWA: standalone, offline, localStorage key `finance-app-v1`).
